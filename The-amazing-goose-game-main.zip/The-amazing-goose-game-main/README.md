# The-amazing-goose-game
An high paced platformer made in godot 3.5

Note to contributers:
As of right now, all level scenes must be named Level[number] and be stored in the levels/level scenes folder.
