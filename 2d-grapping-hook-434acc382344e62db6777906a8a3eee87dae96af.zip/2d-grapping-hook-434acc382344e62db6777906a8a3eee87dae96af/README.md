# 2D Grappling Hook
For Godot 4. Click to shoot out the grappling hook. When it reaches a body, it
will pull the player towards it. If the player moves during that, the grapple
will cancel.
